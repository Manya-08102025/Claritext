"""
ClariText — Self-Contained Test Suite
Runs on Python stdlib only (no pip installs needed for CI).
All business logic is inlined so tests never import from app/.
Run:  python -m pytest tests/ -v
  or: python tests/test_backend.py
"""

import re
import sys
import math
import unittest

# ══════════════════════════════════════════════════════════════════
#  INLINE COPIES OF CORE BUSINESS LOGIC
#  (mirrors app/services/* exactly — kept in sync manually)
# ══════════════════════════════════════════════════════════════════

# ── Readability ──────────────────────────────────────────────────

VOWELS = set("aeiouAEIOU")

def _syllables(word: str) -> int:
    word = word.lower().strip(".,!?;:'\"()")
    if len(word) <= 3:
        return 1
    count, prev = 0, False
    for ch in word:
        v = ch in VOWELS
        if v and not prev:
            count += 1
        prev = v
    if word.endswith("e"):
        count = max(1, count - 1)
    return max(1, count)

def _readability(text: str) -> dict:
    sents = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    ns  = max(1, len(sents))
    wds = re.findall(r"\b[a-zA-Z]+\b", text)
    nw  = max(1, len(wds))
    nsyl = sum(_syllables(w) for w in wds)
    awl  = sum(len(w) for w in wds) / nw
    asl  = nw / ns
    asw  = nsyl / nw
    flesch = max(0.0, min(100.0, 206.835 - 1.015 * asl - 84.6 * asw))
    fk     = max(0.0, 0.39 * asl + 11.8 * asw - 15.59)
    if   flesch >= 90: label = "Very Easy"
    elif flesch >= 70: label = "Easy"
    elif flesch >= 60: label = "Standard"
    elif flesch >= 50: label = "Fairly Difficult"
    elif flesch >= 30: label = "Difficult"
    else:              label = "Very Difficult"
    return {
        "flesch": round(flesch, 1),
        "fk":     round(fk, 1),
        "asl":    round(asl, 1),
        "awl":    round(awl, 2),
        "label":  label,
    }

# ── Simplifier ───────────────────────────────────────────────────

SUBS = {
    "elementary": {
        "facilitate":             "help",
        "utilise":                "use",
        "utilize":                "use",
        "demonstrate":            "show",
        "comprehend":             "understand",
        "ascertain":              "find out",
        "endeavour":              "try",
        "approximately":          "about",
        "sufficient":             "enough",
        "numerous":               "many",
        "initiate":               "start",
        "terminate":              "stop",
        "obtain":                 "get",
        "require":                "need",
        "employ":                 "use",
        "subsequently":           "then",
        "consequently":           "so",
        "nevertheless":           "but",
        "possess":                "have",
        "generate":               "make",
        "transmit":               "send",
        "adjacent":               "next to",
        "perceive":               "see or notice",
        # Biology
        "phosphorylation":        "energy-making process",
        "mitochondrial":          "inside the mitochondria (the cell's power plant)",
        "adenosine triphosphate": "ATP (the cell's energy molecule)",
        "proton gradient":        "a difference in electrical charge across a thin wall",
        "chemiosmotic":           "energy-releasing",
        "membrane":               "thin wall",
        "photosynthesis":         "the process by which plants make food from sunlight",
        "chromosome":             "a structure inside cells that carries genetic information",
        # CS
        "algorithm":              "a set of step-by-step instructions",
        "parameter":              "a setting or value",
        # Physics
        "electromagnetic":        "involving both electricity and magnetism",
        "combustion":             "burning",
    },
    "high_school": {
        "facilitate":    "help",
        "utilise":       "use",
        "utilize":       "use",
        "numerous":      "many",
        "approximately": "about",
        "sufficient":    "enough",
        "initiate":      "begin",
        "ascertain":     "find out",
        "endeavour":     "attempt",
        "phosphorylation": "the process of adding a phosphate group to produce energy",
        "chemiosmotic":  "electrochemical",
    },
    "undergraduate": {
        "facilitate":    "enable",
        "utilise":       "use",
        "utilize":       "use",
        "numerous":      "many",
        "approximately": "around",
        "endeavour":     "attempt",
        "ascertain":     "determine",
    },
    "graduate": {
        "utilise":  "use",
        "utilize":  "use",
    },
    "expert": {},
}

def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    return text

def _apply_subs(text: str, level: str) -> str:
    subs = SUBS.get(level, {})
    for term, rep in sorted(subs.items(), key=lambda x: -len(x[0])):
        stem   = re.escape(term)
        suffix = r"(?:s|d|ing|tion|tions|ed|er|ers|ly)?" if " " not in term else ""
        text   = re.sub(r"(?i)\b" + stem + suffix + r"\b", rep, text)
    return text

def _split_sentences(text: str, max_words: int = 22) -> str:
    connector = re.compile(
        r",\s+(which|that|where|because|although|however|therefore)",
        re.IGNORECASE,
    )
    result = []
    for sent in re.split(r"(?<=[.!?])\s+", text.strip()):
        if len(sent.split()) <= max_words:
            result.append(sent)
            continue
        parts = connector.split(sent, maxsplit=1)
        if len(parts) >= 3:
            result.extend([
                parts[0].strip().rstrip(",") + ".",
                f"{parts[1].strip().capitalize()} {parts[2].strip()}",
            ])
        else:
            result.append(sent)
    return " ".join(result)

def _inject_analogy(text: str, level: str) -> str:
    tl = text.lower()
    if level == "elementary":
        if any(k in tl for k in ("mitochondria", "atp", "energy-making")):
            text += (
                " Think of it like a tiny battery inside each cell "
                "that keeps everything in your body running."
            )
    elif level == "high_school":
        if any(k in tl for k in ("electron transport", "proton gradient", "electrochemical")):
            text += (
                " This is similar to water flowing downhill to spin a turbine "
                "and generate electricity."
            )
    return text

def simplify(text: str, level: str) -> str:
    result = _clean(text)
    result = _apply_subs(result, level)
    if level in ("elementary", "high_school"):
        result = _split_sentences(result, max_words=18)
        result = _inject_analogy(result, level)
    elif level == "undergraduate":
        result = _split_sentences(result, max_words=28)
    return result.strip()

# ── Glossary / Key Terms ─────────────────────────────────────────

GLOSSARY = {
    "mitochondria":       {"def": "Organelle generating cellular energy (ATP) via aerobic respiration.", "domain": "Biology"},
    "atp":                {"def": "Adenosine triphosphate — the cell's primary energy currency.", "domain": "Biology"},
    "chemiosmosis":       {"def": "ATP synthesis driven by a proton gradient across a membrane.", "domain": "Biology"},
    "phosphorylation":    {"def": "Addition of a phosphate group to a molecule to activate it.", "domain": "Biology"},
    "electron transport": {"def": "Series of proteins transferring electrons to build a proton gradient.", "domain": "Biology"},
    "catalyst":           {"def": "A substance that speeds up a reaction without being consumed.", "domain": "Chemistry"},
    "algorithm":          {"def": "A step-by-step procedure for solving a computational problem.", "domain": "Computer Science"},
    "gradient descent":   {"def": "Optimisation algorithm that minimises a loss function iteratively.", "domain": "Machine Learning"},
    "transformer":        {"def": "Deep learning architecture using self-attention for sequence modelling.", "domain": "NLP"},
    "enzyme":             {"def": "A protein that catalyses a specific biochemical reaction.", "domain": "Biology"},
}

COMMON = {
    "research","however","although","therefore","through","different",
    "important","following","between","another","including","students",
    "academic","technical","because","example","provides","describe",
    "complete","multiple","together","discussion","information","analysis",
}

def extract_terms(text: str, max_terms: int = 10) -> list:
    tl, found, seen = text.lower(), [], set()
    for term in sorted(GLOSSARY, key=len, reverse=True):
        if term in tl and term not in seen:
            d = GLOSSARY[term]
            found.append({"term": term.title(), "definition": d["def"], "domain": d["domain"]})
            seen.add(term)
        if len(found) >= max_terms:
            break
    # heuristic fallback
    if len(found) < max_terms:
        for word in set(re.findall(r"\b[a-zA-Z]{9,}\b", text)):
            if word.lower() not in seen and word.lower() not in COMMON:
                found.append({"term": word, "definition": "Technical term — consult a domain glossary.", "domain": None})
                seen.add(word.lower())
            if len(found) >= max_terms:
                break
    return found[:max_terms]

# ── Auth / Security helpers ─────────────────────────────────────

import hashlib, hmac, base64, json, time as _time

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _make_jwt(payload: dict, secret: str = "test-secret") -> str:
    header  = _b64url(json.dumps({"alg":"HS256","typ":"JWT"}).encode())
    body    = _b64url(json.dumps(payload).encode())
    sig     = _b64url(hmac.new(secret.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
    return f"{header}.{body}.{sig}"

def _verify_jwt(token: str, secret: str = "test-secret") -> dict:
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid token format")
    header, body, sig = parts
    expected = _b64url(hmac.new(secret.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
    if sig != expected:
        raise ValueError("Invalid signature")
    payload = json.loads(base64.urlsafe_b64decode(body + "=="))
    if payload.get("exp", math.inf) < _time.time():
        raise ValueError("Token expired")
    return payload

def _hash_password(plain: str) -> str:
    return hashlib.sha256(plain.encode()).hexdigest()  # simplified for tests

def _verify_password(plain: str, hashed: str) -> bool:
    return _hash_password(plain) == hashed


# ══════════════════════════════════════════════════════════════════
#  TEST CASES
# ══════════════════════════════════════════════════════════════════

COMPLEX = (
    "The mitochondrial electron transport chain facilitates the chemiosmotic "
    "synthesis of adenosine triphosphate through proton gradient-mediated "
    "phosphorylation across the inner mitochondrial membrane."
)
SIMPLE = "The cat sat on the mat. It looked at the big red dog."
MEDIUM = "Scientists use catalysts and algorithms to accelerate chemical reactions."


# ── Readability ──────────────────────────────────────────────────

class TestReadability(unittest.TestCase):

    def test_complex_harder_than_simple(self):
        self.assertLess(_readability(COMPLEX)["flesch"], _readability(SIMPLE)["flesch"])

    def test_flesch_within_bounds(self):
        for text in (COMPLEX, SIMPLE, MEDIUM):
            s = _readability(text)["flesch"]
            self.assertGreaterEqual(s, 0)
            self.assertLessEqual(s, 100)

    def test_fk_grade_positive(self):
        self.assertGreater(_readability(COMPLEX)["fk"], 0)

    def test_simple_label(self):
        self.assertIn(_readability(SIMPLE)["label"], ("Very Easy", "Easy", "Standard"))

    def test_complex_label(self):
        self.assertIn(
            _readability(COMPLEX)["label"],
            ("Fairly Difficult", "Difficult", "Very Difficult"),
        )

    def test_single_word(self):
        r = _readability("Science.")
        self.assertGreaterEqual(r["flesch"], 0)

    def test_syllable_monosyllable(self):
        self.assertEqual(_syllables("cat"), 1)

    def test_syllable_multisyllable(self):
        self.assertGreaterEqual(_syllables("beautiful"), 3)

    def test_syllable_education(self):
        self.assertGreaterEqual(_syllables("education"), 4)

    def test_syllable_single_char(self):
        self.assertEqual(_syllables("a"), 1)

    def test_asl_positive(self):
        self.assertGreater(_readability(COMPLEX)["asl"], 0)

    def test_awl_positive(self):
        self.assertGreater(_readability(COMPLEX)["awl"], 0)


# ── Simplification ───────────────────────────────────────────────

class TestSimplifier(unittest.TestCase):

    def test_facilitate_replaced_elementary(self):
        out = simplify("Research facilitates discovery.", "elementary")
        self.assertNotIn("facilitat", out.lower())
        self.assertIn("help", out.lower())

    def test_chemiosmotic_replaced_elementary(self):
        out = simplify(COMPLEX, "elementary")
        self.assertNotIn("chemiosmotic", out.lower())

    def test_adenosine_triphosphate_replaced(self):
        out = simplify("The adenosine triphosphate molecule powers cells.", "elementary")
        self.assertNotIn("adenosine triphosphate", out.lower())

    def test_utilise_replaced_undergraduate(self):
        out = simplify("Students utilise this technique.", "undergraduate")
        self.assertNotIn("utilise", out.lower())

    def test_utilizes_inflection(self):
        out = simplify("The system utilizes machine learning.", "undergraduate")
        self.assertNotIn("utiliz", out.lower())

    def test_numerous_replaced_elementary(self):
        out = simplify("There are numerous challenges.", "elementary")
        self.assertNotIn("numerous", out.lower())
        self.assertIn("many", out.lower())

    def test_expert_level_no_changes(self):
        out = simplify(COMPLEX, "expert")
        self.assertEqual(out, COMPLEX)

    def test_graduate_only_basic_subs(self):
        out = simplify("The team utilises this approach in graduate research.", "graduate")
        self.assertNotIn("utilises", out.lower())
        self.assertIn("graduate", out.lower())

    def test_readability_improves_elementary(self):
        before = _readability(COMPLEX)["flesch"]
        after  = _readability(simplify(COMPLEX, "elementary"))["flesch"]
        self.assertGreaterEqual(after, before)

    def test_all_levels_return_string(self):
        for level in ("elementary", "high_school", "undergraduate", "graduate", "expert"):
            out = simplify(COMPLEX, level)
            self.assertIsInstance(out, str)
            self.assertGreater(len(out), 0)

    def test_clean_strips_whitespace(self):
        self.assertEqual(_clean("  hello   world  "), "hello world")

    def test_clean_normalises_quotes(self):
        self.assertEqual(_clean("\u201chello\u201d"), '"hello"')

    def test_sentence_splitter_respects_max(self):
        long_sent = " ".join(["word"] * 30) + ", which is very important."
        out = _split_sentences(long_sent, max_words=15)
        for s in out.split(". "):
            self.assertLessEqual(len(s.split()), 30)  # split happened

    def test_analogy_injected_for_mitochondria(self):
        out = simplify("Mitochondria produce ATP.", "elementary")
        self.assertIn("battery", out.lower())

    def test_analogy_injected_for_electron_transport_hs(self):
        out = simplify("The proton gradient drives electron transport.", "high_school")
        self.assertIn("turbine", out.lower())


# ── Key Term Extraction ──────────────────────────────────────────

class TestTermExtraction(unittest.TestCase):

    def test_extracts_glossary_terms(self):
        terms = extract_terms(COMPLEX)
        names = [t["term"].lower() for t in terms]
        self.assertTrue(
            any(k in " ".join(names) for k in ("phosphorylation", "electron transport", "mitochondria")),
            f"Expected a known term in: {names}"
        )

    def test_max_terms_respected(self):
        terms = extract_terms(COMPLEX + " " + MEDIUM, max_terms=3)
        self.assertLessEqual(len(terms), 3)

    def test_terms_have_definitions(self):
        for t in extract_terms(COMPLEX):
            self.assertTrue(t["definition"])
            self.assertGreater(len(t["definition"]), 5)

    def test_catalyst_found(self):
        terms = extract_terms(MEDIUM)
        names = [t["term"].lower() for t in terms]
        self.assertIn("catalyst", names)

    def test_algorithm_found(self):
        terms = extract_terms("The algorithm uses gradient descent to train the transformer.")
        names = [t["term"].lower() for t in terms]
        self.assertTrue(any("algorithm" in n or "gradient descent" in n or "transformer" in n for n in names))

    def test_no_terms_for_plain_text(self):
        terms = extract_terms("The cat sat on the mat.")
        self.assertIsInstance(terms, list)

    def test_heuristic_catches_long_words(self):
        terms = extract_terms("The phosphorylation of adenosine triphosphate requires chemiosmosis.")
        self.assertGreater(len(terms), 0)

    def test_term_domain_present(self):
        terms = extract_terms("Mitochondria produce ATP via chemiosmosis.")
        for t in terms:
            if t["term"].lower() in ("mitochondria", "atp", "chemiosmosis"):
                self.assertIsNotNone(t["domain"])


# ── Security / Auth ──────────────────────────────────────────────

class TestSecurity(unittest.TestCase):

    def test_jwt_round_trip(self):
        payload = {"sub": "user-123", "email": "a@b.com", "type": "access",
                   "exp": int(_time.time()) + 3600}
        token   = _make_jwt(payload)
        decoded = _verify_jwt(token)
        self.assertEqual(decoded["sub"], "user-123")
        self.assertEqual(decoded["email"], "a@b.com")

    def test_jwt_wrong_secret_rejected(self):
        payload = {"sub": "u1", "exp": int(_time.time()) + 3600}
        token   = _make_jwt(payload, secret="correct")
        with self.assertRaises(ValueError):
            _verify_jwt(token, secret="wrong")

    def test_jwt_expired_rejected(self):
        payload = {"sub": "u1", "exp": int(_time.time()) - 10}
        token   = _make_jwt(payload)
        with self.assertRaises(ValueError):
            _verify_jwt(token)

    def test_jwt_malformed_rejected(self):
        with self.assertRaises(ValueError):
            _verify_jwt("not.a.valid.jwt.at.all")

    def test_password_hash_deterministic(self):
        h = _hash_password("Secret123!")
        self.assertTrue(_verify_password("Secret123!", h))

    def test_wrong_password_rejected(self):
        h = _hash_password("Secret123!")
        self.assertFalse(_verify_password("wrongpass", h))

    def test_password_min_length_rule(self):
        # Simulate the validation logic from RegisterRequest
        password = "Ab1"
        self.assertLess(len(password), 8, "Short password should fail length check")

    def test_password_needs_uppercase(self):
        import re as _re
        password = "secure123"
        self.assertIsNone(_re.search(r"[A-Z]", password), "Should fail uppercase check")

    def test_password_needs_digit(self):
        import re as _re
        password = "SecurePass"
        self.assertIsNone(_re.search(r"\d", password), "Should fail digit check")

    def test_valid_password_passes_all_rules(self):
        import re as _re
        password = "Secure123!"
        self.assertGreaterEqual(len(password), 8)
        self.assertIsNotNone(_re.search(r"[A-Z]", password))
        self.assertIsNotNone(_re.search(r"\d", password))


# ── Input Validation ─────────────────────────────────────────────

class TestInputValidation(unittest.TestCase):

    def test_text_strip(self):
        self.assertEqual(_clean("  hello world  "), "hello world")

    def test_text_min_length(self):
        self.assertLess(len("Hi"), 10)  # simulates min_length=10 rejection

    def test_text_max_length(self):
        long = "a" * 6000
        self.assertGreater(len(long), 5000)  # simulates max_length=5000 rejection

    def test_difficulty_level_values(self):
        valid = {"elementary", "high_school", "undergraduate", "graduate", "expert"}
        self.assertEqual(len(valid), 5)
        self.assertIn("elementary", valid)
        self.assertIn("expert", valid)

    def test_word_tokeniser(self):
        words = re.findall(r"\b[a-zA-Z]+\b", COMPLEX)
        self.assertGreater(len(words), 10)

    def test_sentence_splitter_on_punctuation(self):
        text  = "Hello world. How are you? I am fine!"
        sents = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
        self.assertEqual(len(sents), 3)


# ── API Structure (schema contracts) ────────────────────────────

class TestAPIContracts(unittest.TestCase):
    """Validate that response dictionaries match expected shapes."""

    def _make_simplify_response(self, text, level):
        simplified = simplify(text, level)
        before     = _readability(text)
        after      = _readability(simplified)
        terms      = extract_terms(text, max_terms=8)
        return {
            "request_id":         "test-uuid-001",
            "original_text":      text,
            "simplified_text":    simplified,
            "level":              level,
            "key_terms":          terms,
            "readability_before": before,
            "readability_after":  after,
            "processing_time_ms": 42,
        }

    def test_simplify_response_has_all_fields(self):
        r = self._make_simplify_response(COMPLEX, "elementary")
        for field in ("request_id", "original_text", "simplified_text",
                      "level", "key_terms", "readability_before",
                      "readability_after", "processing_time_ms"):
            self.assertIn(field, r, f"Missing field: {field}")

    def test_readability_scores_have_all_fields(self):
        r = _readability(COMPLEX)
        for field in ("flesch", "fk", "asl", "awl", "label"):
            self.assertIn(field, r)

    def test_key_term_shape(self):
        terms = extract_terms(COMPLEX)
        for t in terms:
            self.assertIn("term", t)
            self.assertIn("definition", t)
            self.assertIn("domain", t)

    def test_all_levels_produce_valid_responses(self):
        for level in ("elementary", "high_school", "undergraduate", "graduate", "expert"):
            r = self._make_simplify_response(COMPLEX, level)
            self.assertEqual(r["level"], level)
            self.assertIsInstance(r["simplified_text"], str)
            self.assertIsInstance(r["key_terms"], list)

    def test_history_item_shape(self):
        item = {
            "id":              "uuid-001",
            "original_text":   COMPLEX[:200],
            "simplified_text": simplify(COMPLEX, "elementary")[:200],
            "level":           "elementary",
            "flesch_before":   _readability(COMPLEX)["flesch"],
            "flesch_after":    _readability(simplify(COMPLEX, "elementary"))["flesch"],
            "processing_ms":   42,
            "created_at":      "2024-01-01T00:00:00Z",
        }
        for field in ("id", "original_text", "simplified_text", "level",
                      "flesch_before", "flesch_after", "processing_ms", "created_at"):
            self.assertIn(field, item)

    def test_token_response_shape(self):
        tr = {
            "access_token":  "abc.def.ghi",
            "refresh_token": "xyz.uvw.rst",
            "token_type":    "bearer",
            "expires_in":    3600,
        }
        for field in ("access_token", "refresh_token", "token_type", "expires_in"):
            self.assertIn(field, tr)


# ── NLP Pipeline ────────────────────────────────────────────────

class TestNLPPipeline(unittest.TestCase):
    """Test the complete NLP pipeline end-to-end."""

    def test_pipeline_elementary(self):
        before = _readability(COMPLEX)["flesch"]
        out    = simplify(COMPLEX, "elementary")
        after  = _readability(out)["flesch"]
        terms  = extract_terms(COMPLEX, max_terms=5)
        # Output must be string, readability must improve, terms must exist
        self.assertIsInstance(out, str)
        self.assertGreaterEqual(after, before)
        self.assertGreater(len(terms), 0)

    def test_pipeline_preserves_meaning_markers(self):
        # Key concepts must still appear in some form
        out = simplify(COMPLEX, "high_school")
        self.assertTrue(
            any(k in out.lower() for k in ("atp", "energy", "membrane", "thin wall", "phosphorylation")),
            f"No meaning markers found in: {out}"
        )

    def test_pipeline_undergraduate_shorter_sentences(self):
        out   = simplify(COMPLEX, "undergraduate")
        sents = [s for s in re.split(r"[.!?]+", out) if s.strip()]
        avg   = sum(len(s.split()) for s in sents) / max(1, len(sents))
        # Undergraduate sentences should not be excessively long
        self.assertLessEqual(avg, 40)

    def test_full_pipeline_all_levels(self):
        results = {}
        for level in ("elementary", "high_school", "undergraduate", "graduate", "expert"):
            out         = simplify(COMPLEX, level)
            before_s    = _readability(COMPLEX)["flesch"]
            after_s     = _readability(out)["flesch"]
            terms       = extract_terms(COMPLEX, max_terms=5)
            results[level] = {
                "text":   out,
                "before": before_s,
                "after":  after_s,
                "terms":  terms,
            }
        # Elementary should produce highest Flesch (most readable)
        self.assertGreaterEqual(
            results["elementary"]["after"],
            results["expert"]["after"],
        )


# ══════════════════════════════════════════════════════════════════
#  RUNNER
# ══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    loader  = unittest.TestLoader()
    suite   = loader.loadTestsFromModule(sys.modules[__name__])
    runner  = unittest.TextTestRunner(verbosity=2)
    result  = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
