"""
ClariText — Test Suite
Run:  pytest tests/ -v
"""

import pytest
from app.services.nlp_service import compute_readability, extract_key_terms
from app.services.simplifier import simplify_text
from app.models.schemas import DifficultyLevel


# ── Sample academic text ─────────────────────────────────
COMPLEX = (
    "The mitochondrial electron transport chain facilitates the chemiosmotic "
    "synthesis of adenosine triphosphate through proton gradient-mediated "
    "phosphorylation across the inner mitochondrial membrane via the F₀F₁ "
    "ATP synthase complex."
)

SIMPLE = "The cat sat on the mat and looked at the big dog."


# ══════════════════════════════════════════════════════════
#  READABILITY TESTS
# ══════════════════════════════════════════════════════════

class TestReadability:

    def test_scores_returned(self):
        scores = compute_readability(COMPLEX)
        assert scores.flesch_reading_ease >= 0
        assert scores.flesch_kincaid_grade >= 0
        assert scores.avg_sentence_length > 0
        assert scores.label in (
            "Very Easy", "Easy", "Standard",
            "Fairly Difficult", "Difficult", "Very Difficult",
        )

    def test_complex_text_is_harder_than_simple(self):
        complex_score = compute_readability(COMPLEX).flesch_reading_ease
        simple_score  = compute_readability(SIMPLE).flesch_reading_ease
        assert complex_score < simple_score, (
            f"Complex ({complex_score:.1f}) should score lower than simple ({simple_score:.1f})"
        )

    def test_single_sentence(self):
        scores = compute_readability("Hello world.")
        assert scores.flesch_reading_ease >= 0

    def test_label_for_very_easy(self):
        assert compute_readability(SIMPLE).label in ("Very Easy", "Easy", "Standard")

    def test_label_for_very_difficult(self):
        assert compute_readability(COMPLEX).label in (
            "Fairly Difficult", "Difficult", "Very Difficult"
        )


# ══════════════════════════════════════════════════════════
#  KEY TERM EXTRACTION TESTS
# ══════════════════════════════════════════════════════════

class TestTermExtraction:

    def test_extracts_known_terms(self):
        terms = extract_key_terms(COMPLEX)
        term_names = [t.term.lower() for t in terms]
        # At least one of these should be detected
        found = any(
            kw in " ".join(term_names)
            for kw in ["mitochondria", "phosphorylation", "atp", "electron transport"]
        )
        assert found, f"No expected terms found in: {term_names}"

    def test_max_terms_respected(self):
        terms = extract_key_terms(COMPLEX, max_terms=3)
        assert len(terms) <= 3

    def test_all_terms_have_definitions(self):
        terms = extract_key_terms(COMPLEX)
        for t in terms:
            assert t.definition, f"Term '{t.term}' has no definition"
            assert len(t.definition) > 5

    def test_empty_text_returns_empty(self):
        terms = extract_key_terms("A.", max_terms=5)
        assert isinstance(terms, list)


# ══════════════════════════════════════════════════════════
#  SIMPLIFICATION TESTS
# ══════════════════════════════════════════════════════════

class TestSimplifier:

    def test_elementary_shorter_or_clearer(self):
        result = simplify_text(COMPLEX, DifficultyLevel.ELEMENTARY)
        assert len(result) > 0
        # Should replace some technical terms
        assert "facilitate" not in result.lower() or "help" in result.lower()

    def test_output_is_string(self):
        for level in DifficultyLevel:
            result = simplify_text(COMPLEX, level)
            assert isinstance(result, str)
            assert len(result) > 0

    def test_expert_level_mostly_unchanged(self):
        result = simplify_text(COMPLEX, DifficultyLevel.EXPERT)
        # Expert mode: minimal changes — should still contain core domain words
        assert "phosphorylation" in result or "ATP" in result or "mitochondrial" in result

    def test_readability_improves_for_elementary(self):
        from app.services.nlp_service import compute_readability
        before = compute_readability(COMPLEX).flesch_reading_ease
        simplified = simplify_text(COMPLEX, DifficultyLevel.ELEMENTARY)
        after = compute_readability(simplified).flesch_reading_ease
        assert after >= before, (
            f"Elementary simplification did not improve readability: {before:.1f} → {after:.1f}"
        )

    def test_substitution_utilise(self):
        text = "Students should utilise this method."
        result = simplify_text(text, DifficultyLevel.UNDERGRADUATE)
        assert "utilize" not in result.lower() and "utilise" not in result.lower()
        assert "use" in result.lower()

    def test_analogy_appended_for_elementary(self):
        result = simplify_text(COMPLEX, DifficultyLevel.ELEMENTARY)
        # Analogy should be injected
        assert "battery" in result.lower() or "energy" in result.lower()


# ══════════════════════════════════════════════════════════
#  SCHEMA VALIDATION TESTS
# ══════════════════════════════════════════════════════════

class TestSchemas:

    def test_simplify_request_strips_whitespace(self):
        from app.models.schemas import SimplifyRequest
        req = SimplifyRequest(text="  hello world  ")
        assert req.text == "hello world"

    def test_simplify_request_rejects_short_text(self):
        from pydantic import ValidationError
        from app.models.schemas import SimplifyRequest
        with pytest.raises(ValidationError):
            SimplifyRequest(text="Hi")

    def test_simplify_request_rejects_too_long(self):
        from pydantic import ValidationError
        from app.models.schemas import SimplifyRequest
        with pytest.raises(ValidationError):
            SimplifyRequest(text="x" * 5001)

    def test_difficulty_levels_enum(self):
        assert DifficultyLevel.ELEMENTARY == "elementary"
        assert DifficultyLevel.EXPERT     == "expert"
