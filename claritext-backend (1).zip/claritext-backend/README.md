# ClariText — FastAPI Backend

> AI-powered academic text simplification backend.
> Built with **FastAPI · Supabase PostgreSQL · NLP + Transformer Models**.

---

## Table of Contents

1. [Architecture](#architecture)
2. [Project Structure](#project-structure)
3. [Quick Start](#quick-start)
4. [Environment Variables](#environment-variables)
5. [Supabase Setup](#supabase-setup)
6. [API Reference](#api-reference)
7. [NLP Pipeline](#nlp-pipeline)
8. [Running Tests](#running-tests)
9. [Docker Deployment](#docker-deployment)
10. [Upgrade to Transformer Models](#upgrade-to-transformer-models)

---

## Architecture

```
React Frontend
      │
      │ HTTP/JSON
      ▼
┌─────────────────────────────────────────┐
│            FastAPI Backend              │
│                                         │
│  ┌──────────┐   ┌──────────────────┐   │
│  │   Auth   │   │  /api/v1/        │   │
│  │  Routes  │   │  simplify        │   │
│  │          │   │  terms           │   │
│  │  JWT     │   │  history         │   │
│  └──────────┘   └──────────────────┘   │
│        │                 │             │
│        ▼                 ▼             │
│  ┌──────────────────────────────────┐  │
│  │         Service Layer            │  │
│  │  AuthService  │  SimplifierSvc   │  │
│  │  HistorySvc   │  NLPService      │  │
│  └──────────────────────────────────┘  │
│        │                 │             │
│        ▼                 ▼             │
│  ┌─────────────┐   ┌─────────────┐    │
│  │  Supabase   │   │  NLP/ML     │    │
│  │  PostgreSQL │   │  Pipeline   │    │
│  └─────────────┘   └─────────────┘    │
└─────────────────────────────────────────┘
```

---

## Project Structure

```
claritext-backend/
│
├── app/
│   ├── main.py                  # FastAPI app, middleware, lifespan
│   │
│   ├── api/
│   │   ├── router.py            # Central router (mounts all sub-routers)
│   │   └── routes/
│   │       ├── auth.py          # POST /register, /login, /refresh, GET /me
│   │       ├── simplify.py      # POST /simplify
│   │       ├── terms.py         # POST /terms
│   │       ├── history.py       # GET/DELETE /history
│   │       └── health.py        # GET /health
│   │
│   ├── core/
│   │   ├── config.py            # Pydantic Settings (env vars)
│   │   ├── security.py          # JWT creation/verification, bcrypt
│   │   ├── dependencies.py      # FastAPI dependency injection
│   │   └── logging.py           # Structured logging setup
│   │
│   ├── db/
│   │   ├── supabase_client.py   # Supabase client singleton
│   │   └── migrations.sql       # Full PostgreSQL schema (run once)
│   │
│   ├── models/
│   │   └── schemas.py           # All Pydantic request/response models
│   │
│   ├── services/
│   │   ├── auth_service.py      # Registration, login, token refresh
│   │   ├── simplifier.py        # NLP simplification pipeline
│   │   ├── nlp_service.py       # Readability scoring + term extraction
│   │   └── history_service.py   # CRUD for text_history table
│   │
│   └── utils/
│       └── text_utils.py        # Shared text processing helpers
│
├── tests/
│   └── test_backend.py          # 61 unit tests (stdlib only)
│
├── .env.example                 # Template for environment variables
├── requirements.txt             # Python dependencies
├── Dockerfile                   # Production multi-stage build
├── docker-compose.yml           # Local dev stack
└── run.py                       # Dev server entrypoint
```

---

## Quick Start

### 1. Clone & install

```bash
git clone https://github.com/yourname/claritext-backend.git
cd claritext-backend

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env — fill in your Supabase URL and keys
```

### 3. Set up the database

Run `app/db/migrations.sql` in the **Supabase SQL Editor**
(Dashboard → SQL Editor → New Query → paste → Run).

### 4. Start the server

```bash
python run.py
# or
uvicorn app.main:app --reload
```

Open **http://localhost:8000/docs** for the interactive Swagger UI.

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `SUPABASE_URL` | ✅ | Your Supabase project URL |
| `SUPABASE_ANON_KEY` | ✅ | Public anon key |
| `SUPABASE_SERVICE_KEY` | ✅ | Service role key (backend only) |
| `SECRET_KEY` | ✅ | JWT signing secret (generate with `openssl rand -hex 32`) |
| `APP_ENV` | — | `development` or `production` (default: `development`) |
| `DEBUG` | — | `true` / `false` (default: `false`) |
| `CORS_ORIGINS` | — | JSON list of allowed origins |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | — | Default: `60` |
| `REFRESH_TOKEN_EXPIRE_DAYS` | — | Default: `7` |
| `RATE_LIMIT_PER_MINUTE` | — | Requests per IP per minute (default: `30`) |
| `SIMPLIFICATION_MODEL` | — | HuggingFace model ID (for production ML) |
| `DEVICE` | — | `cpu` or `cuda` |

---

## Supabase Setup

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Go to **Settings → API** and copy:
   - Project URL → `SUPABASE_URL`
   - `anon` public key → `SUPABASE_ANON_KEY`
   - `service_role` secret key → `SUPABASE_SERVICE_KEY`
3. Go to **Settings → Database → Connection String** and copy the URI → `DATABASE_URL`
4. Go to **SQL Editor** and run `app/db/migrations.sql`

### Database Schema

```
users
  id (UUID PK)
  email (unique)
  password (bcrypt hash)
  full_name
  created_at
  updated_at
  is_active

text_history
  id (UUID PK)
  user_id (FK → users.id)
  original_text
  simplified_text
  difficulty_level  (elementary | high_school | undergraduate | graduate | expert)
  flesch_before
  flesch_after
  fk_grade_before
  fk_grade_after
  processing_ms
  created_at

key_terms
  id (UUID PK)
  history_id (FK → text_history.id)
  term
  definition
  domain
```

---

## API Reference

All routes return JSON. Protected routes require:
```
Authorization: Bearer <access_token>
```

### Authentication

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/v1/auth/register` | — | Create new account |
| `POST` | `/api/v1/auth/login` | — | Login, receive JWT tokens |
| `POST` | `/api/v1/auth/refresh` | — | Refresh access token |
| `GET` | `/api/v1/auth/me` | ✅ | Get current user profile |

#### Register
```json
POST /api/v1/auth/register
{
  "email": "student@university.edu",
  "password": "Secure123!",
  "full_name": "Alice Smith"
}
```

#### Login
```json
POST /api/v1/auth/login
{
  "email": "student@university.edu",
  "password": "Secure123!"
}
→
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

---

### Simplification

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/v1/simplify` | ✅ | Simplify text |
| `POST` | `/api/v1/terms` | ✅ | Extract key terms only |

#### Simplify
```json
POST /api/v1/simplify
{
  "text": "The mitochondrial electron transport chain facilitates...",
  "level": "undergraduate",
  "extract_terms": true
}
→
{
  "request_id": "uuid",
  "original_text": "...",
  "simplified_text": "...",
  "level": "undergraduate",
  "key_terms": [
    { "term": "Mitochondria", "definition": "...", "domain": "Biology" }
  ],
  "readability_before": {
    "flesch_reading_ease": 14.2,
    "flesch_kincaid_grade": 22.1,
    "avg_sentence_length": 28.0,
    "avg_word_length": 7.4,
    "label": "Very Difficult"
  },
  "readability_after": {
    "flesch_reading_ease": 52.8,
    "flesch_kincaid_grade": 11.3,
    "avg_sentence_length": 18.0,
    "avg_word_length": 5.6,
    "label": "Fairly Difficult"
  },
  "processing_time_ms": 38
}
```

**Difficulty Levels:**
| Value | Target Audience |
|---|---|
| `elementary` | Primary school (age 8–12) |
| `high_school` | Secondary school (age 13–18) |
| `undergraduate` | University first/second year |
| `graduate` | Masters / PhD students |
| `expert` | Domain specialists — no changes |

---

### History

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `GET` | `/api/v1/history` | ✅ | Paginated history list |
| `GET` | `/api/v1/history/{id}` | ✅ | Full detail with key terms |
| `DELETE` | `/api/v1/history/{id}` | ✅ | Delete entry |

```
GET /api/v1/history?page=1&limit=20
```

---

### Health

```
GET /health
→ { "status": "ok", "version": "1.0.0", "services": {...}, "uptime_sec": 142.3 }
```

---

## NLP Pipeline

```
Input Text
    │
    ▼ 1. Text Cleaning
         • Collapse whitespace
         • Normalise Unicode quotes
    │
    ▼ 2. Readability Scoring (BEFORE)
         • Flesch Reading Ease
         • Flesch-Kincaid Grade Level
    │
    ▼ 3. Lexical Substitution
         • Level-specific vocabulary tables
         • Longest-match-first (multi-word phrases)
         • Inflection-aware regex (facilitates → help)
    │
    ▼ 4. Sentence Splitting
         • Max word threshold per level
         • Splits at subordinate clause connectors
    │
    ▼ 5. Analogy Injection (Elementary / High School)
         • Appends domain-appropriate analogies
    │
    ▼ 6. Key Term Extraction
         • 40+ glossary terms across Biology, Chemistry,
           Physics, CS, Economics, Mathematics
         • Heuristic fallback for unknown long words
    │
    ▼ 7. Readability Scoring (AFTER)
    │
    ▼ Output + Persist to Supabase
```

---

## Running Tests

```bash
# Run all 61 tests (no pip installs needed — stdlib only)
python tests/test_backend.py

# Or with pytest if installed
pytest tests/ -v

# Output: 61 tests in 7 categories
#   TestReadability       (12 tests)
#   TestSimplifier        (14 tests)
#   TestTermExtraction    (8 tests)
#   TestSecurity          (9 tests)
#   TestInputValidation   (6 tests)
#   TestAPIContracts      (6 tests)
#   TestNLPPipeline       (6 tests)
```

---

## Docker Deployment

```bash
# Build and start
docker-compose up --build

# API available at http://localhost:8000
# Docs at         http://localhost:8000/docs
```

For **Render / Railway / AWS**:
1. Push to GitHub
2. Set all env vars in the platform dashboard
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`

---

## Upgrade to Transformer Models

The rule-based pipeline is designed as a drop-in replacement for a transformer model.
To upgrade to T5 or BART:

```bash
pip install transformers torch sentencepiece
```

Then in `app/services/simplifier.py`:
1. Uncomment the `TransformerSimplifier` class
2. In `SimplifierService.initialize()`, replace:
   ```python
   logger.info("Simplifier service initialised (rule-based pipeline).")
   ```
   with:
   ```python
   self._transformer = TransformerSimplifier(settings.SIMPLIFICATION_MODEL, settings.DEVICE)
   self._transformer.load()
   ```
3. In `SimplifierService.run()`, delegate to `self._transformer.run(text, level)`
4. Set `SIMPLIFICATION_MODEL=facebook/bart-large-cnn` (or your fine-tuned weights) in `.env`

---

## Security Notes

- All passwords are stored as **bcrypt hashes** — never plain text
- The `SUPABASE_SERVICE_KEY` bypasses Row-Level Security — keep it server-side only
- JWT tokens are signed with HS256 — rotate `SECRET_KEY` in production
- Rate limiting is applied per IP via `slowapi`
- All inputs are validated by Pydantic before reaching business logic

---

*ClariText Backend v1.0.0 — FastAPI + Supabase + NLP*
