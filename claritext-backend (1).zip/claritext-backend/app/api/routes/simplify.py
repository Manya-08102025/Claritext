"""
ClariText — Simplification Route
POST /api/v1/simplify
"""

import uuid
import logging
from fastapi import APIRouter, Depends, HTTPException, status

from app.models.schemas import SimplifyRequest, SimplifyResponse
from app.services.nlp_service import nlp_service
from app.services.simplifier import simplifier_service
from app.services.history_service import history_service
from app.core.dependencies import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Simplification"])


@router.post(
    "/simplify",
    response_model=SimplifyResponse,
    summary="Simplify academic or technical text",
    description=(
        "Accepts up to 5 000 characters of academic or technical text and returns "
        "a simplified version at the specified difficulty level, along with "
        "key term definitions and before/after readability scores.\n\n"
        "**Requires authentication** — include a Bearer token in the Authorization header."
    ),
)
async def simplify(
    body: SimplifyRequest,
    current_user: dict = Depends(get_current_user),
) -> SimplifyResponse:

    # Guard: services must be initialised
    if not nlp_service.ready or not simplifier_service.ready:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="NLP services are still loading. Please retry in a moment.",
        )

    # ── Readability BEFORE ────────────────────────────────────────
    readability_before = nlp_service.score_readability(body.text)

    # ── Simplification ────────────────────────────────────────────
    simplified_text, processing_ms = await simplifier_service.run(body.text, body.level)

    # ── Readability AFTER ─────────────────────────────────────────
    readability_after = nlp_service.score_readability(simplified_text)

    # ── Key Term Extraction ───────────────────────────────────────
    key_terms = nlp_service.extract_terms(body.text, max_terms=8) if body.extract_terms else []

    # ── Build response ────────────────────────────────────────────
    response = SimplifyResponse(
        request_id=str(uuid.uuid4()),
        original_text=body.text,
        simplified_text=simplified_text,
        level=body.level,
        key_terms=key_terms,
        readability_before=readability_before,
        readability_after=readability_after,
        processing_time_ms=processing_ms,
    )

    # ── Persist (non-blocking, best-effort) ───────────────────────
    try:
        await history_service.save(current_user["user_id"], response)
    except Exception as exc:
        logger.warning(f"History persistence failed (non-fatal): {exc}")

    logger.info(
        f"Simplified | user={current_user['email']} | "
        f"level={body.level.value} | "
        f"flesch {readability_before.flesch_reading_ease}→"
        f"{readability_after.flesch_reading_ease} | {processing_ms}ms"
    )

    return response
