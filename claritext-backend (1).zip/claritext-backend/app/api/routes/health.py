"""
ClariText — Health Check
GET /health
"""

import time
from fastapi import APIRouter
from app.models.schemas import HealthResponse
from app.services.nlp_service import nlp_service
from app.services.simplifier import simplifier_service

router = APIRouter(tags=["Health"])
_START = time.monotonic()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="API health check",
    description="Returns the status of the API and its internal services. Use this for monitoring.",
)
async def health_check() -> HealthResponse:
    all_ok = nlp_service.ready and simplifier_service.ready
    return HealthResponse(
        status="ok" if all_ok else "degraded",
        version="1.0.0",
        services={
            "nlp_service":        "ready" if nlp_service.ready        else "loading",
            "simplifier_service": "ready" if simplifier_service.ready else "loading",
        },
        uptime_sec=round(time.monotonic() - _START, 1),
    )
