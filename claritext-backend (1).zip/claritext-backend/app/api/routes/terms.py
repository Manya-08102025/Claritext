"""
ClariText — Key Term Extraction Route
POST /api/v1/terms
"""

from fastapi import APIRouter, Depends, HTTPException, status
from app.models.schemas import ExtractTermsRequest, ExtractTermsResponse
from app.services.nlp_service import nlp_service
from app.core.dependencies import get_current_user

router = APIRouter(tags=["Key Terms"])


@router.post(
    "/terms",
    response_model=ExtractTermsResponse,
    summary="Extract key technical terms from text",
    description=(
        "Identify and define technical vocabulary within any academic or "
        "technical passage. Useful for building glossaries or study aids."
    ),
)
async def extract_terms(
    body: ExtractTermsRequest,
    current_user: dict = Depends(get_current_user),
) -> ExtractTermsResponse:

    if not nlp_service.ready:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="NLP service not ready.",
        )

    terms = nlp_service.extract_terms(body.text, max_terms=body.max_terms)
    return ExtractTermsResponse(terms=terms, total_found=len(terms))
