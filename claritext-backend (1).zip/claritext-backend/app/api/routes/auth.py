"""
ClariText — Authentication Routes
POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/refresh
GET  /api/v1/auth/me
"""

from fastapi import APIRouter, Depends, status
from app.models.schemas import (
    RegisterRequest, LoginRequest, TokenResponse,
    RefreshRequest, UserOut,
)
from app.services.auth_service import auth_service
from app.core.dependencies import get_current_user

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post(
    "/register",
    response_model=UserOut,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user account",
)
async def register(body: RegisterRequest) -> UserOut:
    """
    Create a new ClariText account.

    - **email**: must be unique
    - **password**: minimum 8 characters, must include uppercase and a digit
    - **full_name**: optional display name
    """
    return await auth_service.register(body)


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login and obtain JWT tokens",
)
async def login(body: LoginRequest) -> TokenResponse:
    """
    Authenticate with email + password.
    Returns:
    - **access_token**: short-lived JWT for API calls
    - **refresh_token**: long-lived JWT to renew access tokens
    """
    return await auth_service.login(body)


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Refresh access token",
)
async def refresh_token(body: RefreshRequest) -> TokenResponse:
    """
    Exchange a valid refresh token for a new access + refresh token pair.
    The old refresh token is invalidated after use (rotation).
    """
    return await auth_service.refresh(body.refresh_token)


@router.get(
    "/me",
    response_model=UserOut,
    summary="Get current user profile",
)
async def get_me(current_user: dict = Depends(get_current_user)) -> UserOut:
    """
    Return the profile of the currently authenticated user.
    Requires a valid Bearer token in the Authorization header.
    """
    return await auth_service.get_profile(current_user["user_id"])
