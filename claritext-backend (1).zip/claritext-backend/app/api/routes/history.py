"""
ClariText — History Routes
GET    /api/v1/history
GET    /api/v1/history/{id}
DELETE /api/v1/history/{id}
"""

from fastapi import APIRouter, Depends, Query, Path
from app.models.schemas import HistoryResponse
from app.services.history_service import history_service
from app.core.dependencies import get_current_user

router = APIRouter(tags=["History"])


@router.get(
    "/history",
    response_model=HistoryResponse,
    summary="Retrieve simplification history",
    description="Return a paginated list of all past simplification requests for the current user.",
)
async def get_history(
    page:  int = Query(default=1,  ge=1,     description="Page number (1-indexed)"),
    limit: int = Query(default=20, ge=1, le=100, description="Results per page"),
    current_user: dict = Depends(get_current_user),
) -> HistoryResponse:
    items, total = await history_service.get_history(
        user_id=current_user["user_id"],
        page=page,
        limit=limit,
    )
    return HistoryResponse(items=items, total=total, page=page, limit=limit)


@router.get(
    "/history/{history_id}",
    summary="Get full detail of a history entry",
    description=(
        "Return the full original text, simplified text, readability scores, "
        "and key terms for a single past request."
    ),
)
async def get_history_detail(
    history_id: str = Path(..., description="UUID of the history entry"),
    current_user: dict = Depends(get_current_user),
) -> dict:
    return await history_service.get_detail(history_id, current_user["user_id"])


@router.delete(
    "/history/{history_id}",
    status_code=204,
    summary="Delete a history entry",
    description="Permanently delete a simplification record and its key terms.",
)
async def delete_history(
    history_id: str = Path(..., description="UUID of the history entry"),
    current_user: dict = Depends(get_current_user),
) -> None:
    await history_service.delete(history_id, current_user["user_id"])
