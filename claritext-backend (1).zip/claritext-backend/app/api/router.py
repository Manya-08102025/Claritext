"""
ClariText — Central API Router
Registers all sub-routers under the /api/v1 prefix.
"""

from fastapi import APIRouter
from app.api.routes import auth, simplify, terms, history

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth.router)
api_router.include_router(simplify.router)
api_router.include_router(terms.router)
api_router.include_router(history.router)
