"""
ClariText — FastAPI Dependencies
Re-usable dependencies for auth, DB, etc.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from app.core.security import decode_token
from app.db.supabase_client import get_supabase

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


async def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    Validate Bearer token and return the authenticated user's id + email.
    Inject this dependency into any protected route.
    """
    payload = decode_token(token)

    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type.",
        )

    user_id: str = payload.get("sub")
    email:   str = payload.get("email", "")

    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token payload missing user id.",
        )

    return {"user_id": user_id, "email": email}


# Optional — let routes work without auth (returns None if no token)
async def get_optional_user(token: str | None = None):
    if not token:
        return None
    try:
        return await get_current_user(token)
    except HTTPException:
        return None
