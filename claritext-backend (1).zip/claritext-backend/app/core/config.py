"""
ClariText — Application Configuration
Loads settings from environment variables / .env file.
"""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List
from functools import lru_cache


class Settings(BaseSettings):

    # ── App ────────────────────────────────────────────────────
    APP_NAME:    str = "ClariText"
    APP_ENV:     str = Field(default="development", env="APP_ENV")
    DEBUG:       bool = Field(default=False, env="DEBUG")
    API_VERSION: str = "v1"

    # ── Server ─────────────────────────────────────────────────
    API_HOST:    str = Field(default="0.0.0.0", env="API_HOST")
    API_PORT:    int = Field(default=8000,       env="API_PORT")
    API_WORKERS: int = Field(default=2,          env="API_WORKERS")

    # ── CORS ───────────────────────────────────────────────────
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:5173"],
        env="CORS_ORIGINS",
    )

    # ── Supabase ───────────────────────────────────────────────
    SUPABASE_URL:         str = Field(default="", env="SUPABASE_URL")
    SUPABASE_ANON_KEY:    str = Field(default="", env="SUPABASE_ANON_KEY")
    SUPABASE_SERVICE_KEY: str = Field(default="", env="SUPABASE_SERVICE_KEY")
    DATABASE_URL:         str = Field(default="", env="DATABASE_URL")

    # ── JWT / Auth ─────────────────────────────────────────────
    SECRET_KEY:                    str = Field(default="change-me-in-production", env="SECRET_KEY")
    ALGORITHM:                     str = Field(default="HS256",  env="ALGORITHM")
    ACCESS_TOKEN_EXPIRE_MINUTES:   int = Field(default=60,       env="ACCESS_TOKEN_EXPIRE_MINUTES")
    REFRESH_TOKEN_EXPIRE_DAYS:     int = Field(default=7,        env="REFRESH_TOKEN_EXPIRE_DAYS")

    # ── ML Models ──────────────────────────────────────────────
    SIMPLIFICATION_MODEL: str  = Field(default="facebook/bart-large-cnn", env="SIMPLIFICATION_MODEL")
    NER_MODEL:            str  = Field(default="en_core_web_sm",           env="NER_MODEL")
    DEVICE:               str  = Field(default="cpu",                      env="DEVICE")
    MAX_INPUT_TOKENS:     int  = Field(default=512,                        env="MAX_INPUT_TOKENS")
    MAX_OUTPUT_TOKENS:    int  = Field(default=256,                        env="MAX_OUTPUT_TOKENS")

    # ── Rate Limiting ──────────────────────────────────────────
    RATE_LIMIT_PER_MINUTE: int = Field(default=30, env="RATE_LIMIT_PER_MINUTE")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
