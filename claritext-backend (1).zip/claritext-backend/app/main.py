"""
ClariText — FastAPI Application Entry Point
"""

import time
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from app.core.config import settings
from app.core.logging import setup_logging
from app.api.router import api_router
from app.api.routes.health import router as health_router
from app.services.nlp_service import nlp_service
from app.services.simplifier import simplifier_service

setup_logging()
logger = logging.getLogger(__name__)


# ── Rate limiter (slowapi) ────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address)


# ── Lifespan: startup / shutdown ─────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    logger.info("   ClariText API  — starting up")
    logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    # Warm up ML services
    await nlp_service.initialize()
    await simplifier_service.initialize()

    logger.info("✅ All services ready. Accepting requests.")
    yield

    logger.info("🛑 ClariText API shutting down.")


# ── Application factory ───────────────────────────────────────────
app = FastAPI(
    title="ClariText API",
    description=(
        "## ClariText — AI-Powered Academic Text Simplification\n\n"
        "Transform complex academic and technical text into clear, "
        "student-friendly explanations using NLP and transformer models.\n\n"
        "### Authentication\n"
        "Most endpoints require a **Bearer JWT** in the `Authorization` header.\n"
        "Use `POST /api/v1/auth/login` to obtain tokens.\n\n"
        "### Rate Limiting\n"
        f"Requests are limited to **{settings.RATE_LIMIT_PER_MINUTE} per minute** per IP."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── State for rate limiter ────────────────────────────────────────
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# ── Middleware ────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=500)


# ── Request timing middleware ─────────────────────────────────────
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start = time.monotonic()
    response = await call_next(request)
    elapsed = round((time.monotonic() - start) * 1000, 1)
    response.headers["X-Process-Time-Ms"] = str(elapsed)
    return response


# ── Global exception handler ──────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception on {request.url}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected internal error occurred. Please try again."},
    )


# ── Routers ───────────────────────────────────────────────────────
app.include_router(health_router)   # GET /health (no prefix)
app.include_router(api_router)      # All routes under /api/v1


# ── Root ──────────────────────────────────────────────────────────
@app.get("/", include_in_schema=False)
async def root():
    return {
        "app":     "ClariText API",
        "version": "1.0.0",
        "docs":    "/docs",
        "health":  "/health",
    }
