-- ══════════════════════════════════════════════════════════════════
--  ClariText — Supabase PostgreSQL Schema
--  Run this in: Supabase Dashboard → SQL Editor
-- ══════════════════════════════════════════════════════════════════

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- ── USERS TABLE ──────────────────────────────────────────────────
-- Note: Supabase manages its own auth.users table.
-- This table stores additional profile data linked to auth.users.
CREATE TABLE IF NOT EXISTS public.users (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    email        TEXT        NOT NULL UNIQUE,
    password     TEXT        NOT NULL,         -- bcrypt hash
    full_name    TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active    BOOLEAN     NOT NULL DEFAULT TRUE
);

-- Auto-update updated_at on row change
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at
    BEFORE UPDATE ON public.users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


-- ── TEXT HISTORY TABLE ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.text_history (
    id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID        NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    original_text    TEXT        NOT NULL,
    simplified_text  TEXT        NOT NULL,
    difficulty_level TEXT        NOT NULL CHECK (
                                    difficulty_level IN (
                                        'elementary','high_school',
                                        'undergraduate','graduate','expert'
                                    )
                                 ),
    -- Readability metrics
    flesch_before    NUMERIC(5,2),
    flesch_after     NUMERIC(5,2),
    fk_grade_before  NUMERIC(5,2),
    fk_grade_after   NUMERIC(5,2),
    processing_ms    INTEGER,
    -- Timestamps
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast per-user history queries
CREATE INDEX IF NOT EXISTS idx_text_history_user_id
    ON public.text_history (user_id, created_at DESC);


-- ── KEY TERMS TABLE ──────────────────────────────────────────────
-- Stores the extracted technical terms per simplification run
CREATE TABLE IF NOT EXISTS public.key_terms (
    id          UUID  PRIMARY KEY DEFAULT gen_random_uuid(),
    history_id  UUID  NOT NULL REFERENCES public.text_history(id) ON DELETE CASCADE,
    term        TEXT  NOT NULL,
    definition  TEXT  NOT NULL,
    domain      TEXT
);

CREATE INDEX IF NOT EXISTS idx_key_terms_history_id
    ON public.key_terms (history_id);


-- ── ROW LEVEL SECURITY ───────────────────────────────────────────
-- Enable RLS on all tables
ALTER TABLE public.users       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.text_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.key_terms   ENABLE ROW LEVEL SECURITY;

-- Users can only read/update their own profile
CREATE POLICY "users_own_row" ON public.users
    FOR ALL USING (id = auth.uid());

-- Users can only access their own history
CREATE POLICY "history_own_rows" ON public.text_history
    FOR ALL USING (user_id = auth.uid());

-- Key terms follow history visibility
CREATE POLICY "key_terms_via_history" ON public.key_terms
    FOR SELECT USING (
        history_id IN (
            SELECT id FROM public.text_history WHERE user_id = auth.uid()
        )
    );

-- ══════════════════════════════════════════════════════════════════
--  END OF SCHEMA
-- ══════════════════════════════════════════════════════════════════
