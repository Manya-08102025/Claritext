"""
ClariText — Supabase Client
Singleton wrapper around the official supabase-py client.
All database operations go through this module.
"""

import logging
from supabase import create_client, Client
from app.core.config import settings

logger = logging.getLogger(__name__)

_supabase_client: Client | None = None


def get_supabase() -> Client:
    """
    Return the shared Supabase client (initialised once on first call).
    Uses the SERVICE_ROLE key so we bypass Row-Level Security for
    server-side operations — keep this key secret on the backend only.
    """
    global _supabase_client
    if _supabase_client is None:
        if not settings.SUPABASE_URL or not settings.SUPABASE_SERVICE_KEY:
            raise RuntimeError(
                "SUPABASE_URL and SUPABASE_SERVICE_KEY must be set in .env"
            )
        _supabase_client = create_client(
            settings.SUPABASE_URL,
            settings.SUPABASE_SERVICE_KEY,
        )
        logger.info(f"Supabase client initialised → {settings.SUPABASE_URL}")
    return _supabase_client


def get_anon_supabase() -> Client:
    """
    Return a Supabase client using the ANON key.
    Respects Row-Level Security — use for user-facing auth flows.
    """
    return create_client(settings.SUPABASE_URL, settings.SUPABASE_ANON_KEY)
