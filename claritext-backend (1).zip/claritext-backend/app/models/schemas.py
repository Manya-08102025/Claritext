"""
ClariText — Pydantic Schemas
All request bodies and response shapes are defined here.
"""

from pydantic import BaseModel, Field, field_validator, EmailStr
from typing import List, Optional, Literal
from datetime import datetime
from enum import Enum
import re


# ═══════════════════════════════════════════════════════
#  ENUMS
# ═══════════════════════════════════════════════════════

class DifficultyLevel(str, Enum):
    ELEMENTARY    = "elementary"
    HIGH_SCHOOL   = "high_school"
    UNDERGRADUATE = "undergraduate"
    GRADUATE      = "graduate"
    EXPERT        = "expert"


# ═══════════════════════════════════════════════════════
#  AUTH SCHEMAS
# ═══════════════════════════════════════════════════════

class RegisterRequest(BaseModel):
    email:     EmailStr
    password:  str = Field(..., min_length=8, max_length=128)
    full_name: Optional[str] = Field(default=None, max_length=120)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain at least one uppercase letter.")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain at least one digit.")
        return v


class LoginRequest(BaseModel):
    email:    EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token:  str
    refresh_token: str
    token_type:    str = "bearer"
    expires_in:    int  # seconds


class UserOut(BaseModel):
    id:         str
    email:      str
    full_name:  Optional[str]
    created_at: datetime
    is_active:  bool


class RefreshRequest(BaseModel):
    refresh_token: str


# ═══════════════════════════════════════════════════════
#  SIMPLIFICATION SCHEMAS
# ═══════════════════════════════════════════════════════

class SimplifyRequest(BaseModel):
    text:          str = Field(..., min_length=10, max_length=5000,
                               description="The academic/technical text to simplify.")
    level:         DifficultyLevel = Field(default=DifficultyLevel.UNDERGRADUATE)
    extract_terms: bool = Field(default=True, description="Extract key technical terms.")

    @field_validator("text")
    @classmethod
    def clean_text(cls, v: str) -> str:
        return v.strip()


class ReadabilityScores(BaseModel):
    flesch_reading_ease: float = Field(description="0–100. Higher = easier to read.")
    flesch_kincaid_grade: float = Field(description="US school grade level equivalent.")
    avg_sentence_length:  float
    avg_word_length:      float
    label:                str   # "Easy", "Difficult", etc.


class KeyTerm(BaseModel):
    term:       str
    definition: str
    domain:     Optional[str] = None


class SimplifyResponse(BaseModel):
    request_id:        str
    original_text:     str
    simplified_text:   str
    level:             DifficultyLevel
    key_terms:         List[KeyTerm]
    readability_before: ReadabilityScores
    readability_after:  ReadabilityScores
    processing_time_ms: int


# ═══════════════════════════════════════════════════════
#  TERMS SCHEMAS
# ═══════════════════════════════════════════════════════

class ExtractTermsRequest(BaseModel):
    text:      str = Field(..., min_length=10, max_length=5000)
    max_terms: int = Field(default=10, ge=1, le=30)


class ExtractTermsResponse(BaseModel):
    terms:       List[KeyTerm]
    total_found: int


# ═══════════════════════════════════════════════════════
#  HISTORY SCHEMAS
# ═══════════════════════════════════════════════════════

class HistoryItem(BaseModel):
    id:              str
    original_text:   str
    simplified_text: str
    level:           DifficultyLevel
    flesch_before:   Optional[float]
    flesch_after:    Optional[float]
    processing_ms:   Optional[int]
    created_at:      datetime


class HistoryResponse(BaseModel):
    items: List[HistoryItem]
    total: int
    page:  int
    limit: int


# ═══════════════════════════════════════════════════════
#  HEALTH SCHEMA
# ═══════════════════════════════════════════════════════

class HealthResponse(BaseModel):
    status:     Literal["ok", "degraded", "down"]
    version:    str
    services:   dict
    uptime_sec: float
