"""
ClariText — Text Simplification Service

Architecture
────────────
• Development (no GPU):  Rule-based lexical substitution pipeline.
• Production (GPU/CPU):  Drop-in HuggingFace T5 / BART fine-tuned model.

Swapping to a transformer is a single-file change:
  1. pip install transformers torch sentencepiece
  2. Set SIMPLIFICATION_MODEL=t5-base (or path to fine-tuned weights) in .env
  3. Uncomment the TransformerSimplifier block below.
"""

import re
import asyncio
import logging
import time
from typing import Dict, Tuple
from app.models.schemas import DifficultyLevel

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════
#  LEVEL-SPECIFIC LEXICAL SUBSTITUTION TABLES
#  technical term → plain alternative, keyed by difficulty level
# ══════════════════════════════════════════════════════════════════

_SUBS: Dict[DifficultyLevel, Dict[str, str]] = {

    DifficultyLevel.ELEMENTARY: {
        # Common academic verbs
        "facilitate":              "help",
        "utilise":                 "use",
        "utilize":                 "use",
        "demonstrate":             "show",
        "comprehend":              "understand",
        "ascertain":               "find out",
        "endeavour":               "try",
        "approximately":           "about",
        "sufficient":              "enough",
        "numerous":                "many",
        "initiate":                "start",
        "terminate":               "stop",
        "obtain":                  "get",
        "require":                 "need",
        "employ":                  "use",
        "subsequently":            "then",
        "consequently":            "so",
        "nevertheless":            "but",
        "possess":                 "have",
        "reside":                  "live",
        "perceive":                "see or notice",
        "generate":                "make",
        "transmit":                "send",
        "adjacent":                "next to",
        "preceding":               "before",
        "subsequent":              "after",
        # Biology terms
        "phosphorylation":         "energy-making process",
        "mitochondrial":           "inside the mitochondria (the cell's power plant)",
        "adenosine triphosphate":  "ATP (the cell's energy molecule)",
        "proton gradient":         "a difference in electrical charge across a thin wall",
        "chemiosmotic":            "energy-releasing",
        "membrane":                "thin wall",
        "photosynthesis":          "the process by which plants make food from sunlight",
        "chromosome":              "a structure inside cells that carries genetic information",
        # Physics / Chemistry
        "electromagnetic":         "involving both electricity and magnetism",
        "acceleration":            "increase in speed",
        "combustion":              "burning",
        # CS
        "algorithm":               "a set of step-by-step instructions",
        "parameter":               "a setting or value",
    },

    DifficultyLevel.HIGH_SCHOOL: {
        "facilitate":              "help",
        "utilise":                 "use",
        "utilize":                 "use",
        "numerous":                "many",
        "approximately":           "about",
        "sufficient":              "enough",
        "initiate":                "begin",
        "ascertain":               "find out",
        "endeavour":               "attempt",
        "phosphorylation":         "the process of adding a phosphate group to produce energy",
        "chemiosmotic":            "electrochemical",
    },

    DifficultyLevel.UNDERGRADUATE: {
        "facilitate":              "enable",
        "utilise":                 "use",
        "utilize":                 "use",
        "numerous":                "many",
        "approximately":           "around",
        "endeavour":               "attempt",
        "ascertain":               "determine",
    },

    DifficultyLevel.GRADUATE: {
        "utilise":                 "use",
        "utilize":                 "use",
    },

    DifficultyLevel.EXPERT: {},   # No changes — preserve all terminology
}


# ══════════════════════════════════════════════════════════════════
#  PROCESSING STEPS
# ══════════════════════════════════════════════════════════════════

def _clean_text(text: str) -> str:
    """
    Input preprocessing:
      • Collapse multiple whitespace characters
      • Strip leading/trailing whitespace
      • Normalise Unicode quotation marks
    """
    text = re.sub(r"\s+", " ", text).strip()
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    return text


def _apply_substitutions(text: str, level: DifficultyLevel) -> str:
    """
    Lexical substitution pass.
    Multi-word phrases matched first (longest → shortest) to avoid partial matches.
    Inflected forms (e.g. 'facilitates', 'facilitated') are also matched via
    optional common suffix pattern.
    """
    subs = _SUBS.get(level, {})
    for term, replacement in sorted(subs.items(), key=lambda x: -len(x[0])):
        stem   = re.escape(term)
        suffix = r"(?:s|d|ing|tion|tions|ed|er|ers|ly)?" if " " not in term else ""
        pattern = re.compile(r"(?i)\b" + stem + suffix + r"\b")
        text = pattern.sub(replacement, text)
    return text


def _split_long_sentences(text: str, max_words: int = 22) -> str:
    """
    Sentence splitting for lower difficulty levels.
    Attempts to split at subordinate clause markers: which, that, where, because.
    """
    connector_re = re.compile(
        r",\s+(which|that|where|because|although|however|therefore)",
        re.IGNORECASE,
    )
    result = []
    for sent in re.split(r"(?<=[.!?])\s+", text.strip()):
        if len(sent.split()) <= max_words:
            result.append(sent)
            continue
        parts = connector_re.split(sent, maxsplit=1)
        if len(parts) >= 3:
            first  = parts[0].strip().rstrip(",") + "."
            bridge = parts[1].strip().capitalize()
            rest   = parts[2].strip()
            result.extend([first, f"{bridge} {rest}"])
        else:
            result.append(sent)
    return " ".join(result)


def _inject_analogy(text: str, level: DifficultyLevel) -> str:
    """
    Append a relatable analogy for lower-level outputs.
    Keeps explanations grounded in everyday experience.
    """
    text_l = text.lower()
    if level == DifficultyLevel.ELEMENTARY:
        if any(k in text_l for k in ("mitochondria", "atp", "energy-making")):
            text += (
                " Think of it like a tiny battery inside each cell "
                "that keeps everything in your body running."
            )
    elif level == DifficultyLevel.HIGH_SCHOOL:
        if any(k in text_l for k in ("electron transport", "proton gradient", "electrochemical")):
            text += (
                " This is similar to water flowing downhill to spin a turbine "
                "and generate electricity."
            )
    return text


def simplify_text(text: str, level: DifficultyLevel) -> str:
    """
    Main simplification pipeline:
      1. Clean  → normalise whitespace / quotes
      2. Substitute → replace technical vocabulary
      3. Split  → break long sentences (for lower levels)
      4. Analogy → add grounding example (for elementary / HS)
    """
    result = _clean_text(text)
    result = _apply_substitutions(result, level)

    if level in (DifficultyLevel.ELEMENTARY, DifficultyLevel.HIGH_SCHOOL):
        result = _split_long_sentences(result, max_words=18)
        result = _inject_analogy(result, level)
    elif level == DifficultyLevel.UNDERGRADUATE:
        result = _split_long_sentences(result, max_words=28)

    return result.strip()


# ══════════════════════════════════════════════════════════════════
#  HuggingFace TRANSFORMER INTEGRATION (production)
#  Uncomment + pip install transformers torch sentencepiece
# ══════════════════════════════════════════════════════════════════

# from transformers import pipeline as _hf_pipeline
#
# class TransformerSimplifier:
#     _PROMPTS = {
#         DifficultyLevel.ELEMENTARY:    "Simplify for a 10-year-old: ",
#         DifficultyLevel.HIGH_SCHOOL:   "Simplify for a high school student: ",
#         DifficultyLevel.UNDERGRADUATE: "Simplify for an undergraduate student: ",
#         DifficultyLevel.GRADUATE:      "Lightly simplify for a graduate student: ",
#         DifficultyLevel.EXPERT:        "Restructure for expert clarity: ",
#     }
#
#     def __init__(self, model_id: str, device: str = "cpu"):
#         self.model_id = model_id
#         self._device  = 0 if device == "cuda" else -1
#         self._pipe    = None
#
#     def load(self):
#         self._pipe = _hf_pipeline(
#             "text2text-generation",
#             model=self.model_id,
#             device=self._device,
#             max_new_tokens=256,
#         )
#
#     def run(self, text: str, level: DifficultyLevel) -> str:
#         prompt = self._PROMPTS[level] + text
#         return self._pipe(prompt, do_sample=False)[0]["generated_text"]


# ══════════════════════════════════════════════════════════════════
#  SERVICE SINGLETON
# ══════════════════════════════════════════════════════════════════

class SimplifierService:

    def __init__(self):
        self._ready = False

    async def initialize(self):
        # Swap with TransformerSimplifier.load() for GPU inference
        logger.info("Simplifier service initialised (rule-based pipeline).")
        self._ready = True

    async def run(self, text: str, level: DifficultyLevel) -> Tuple[str, int]:
        """
        Simplify text and return (simplified_text, processing_time_ms).
        Offloads CPU work to a thread-pool so the event loop stays responsive.
        """
        loop  = asyncio.get_event_loop()
        start = time.monotonic()
        result = await loop.run_in_executor(None, simplify_text, text, level)
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return result, elapsed_ms

    @property
    def ready(self) -> bool:
        return self._ready


simplifier_service = SimplifierService()
