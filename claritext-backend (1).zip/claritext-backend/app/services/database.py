"""
ClariText — Database Service
MongoDB via motor (async driver)
"""

import logging
from datetime import datetime
from typing import List, Optional
from bson import ObjectId
from app.core.config import settings
from app.models.schemas import HistoryItem, SimplifyResponse

logger = logging.getLogger(__name__)


class Database:
    """
    Async MongoDB wrapper.
    Falls back gracefully to in-memory list if MongoDB is unavailable
    (useful for dev / unit tests).
    """

    def __init__(self):
        self._client   = None
        self._db       = None
        self._fallback: list = []   # in-memory fallback
        self._use_mongo = False

    async def connect(self):
        try:
            from motor.motor_asyncio import AsyncIOMotorClient
            self._client = AsyncIOMotorClient(
                settings.MONGO_URI, serverSelectionTimeoutMS=3000
            )
            # Ping to confirm connection
            await self._client.admin.command("ping")
            self._db = self._client[settings.MONGO_DB]
            self._use_mongo = True
            logger.info(f"✅ Connected to MongoDB at {settings.MONGO_URI}")
        except Exception as e:
            logger.warning(
                f"⚠️  MongoDB unavailable ({e}). Using in-memory fallback."
            )
            self._use_mongo = False

    async def disconnect(self):
        if self._client:
            self._client.close()

    # ── History ──────────────────────────────────────────

    async def save_result(self, result: SimplifyResponse) -> str:
        doc = {
            "request_id":       result.request_id,
            "original_text":    result.original_text,
            "simplified_text":  result.simplified_text,
            "level":            result.level.value,
            "flesch_before":    result.readability_before.flesch_reading_ease,
            "flesch_after":     result.readability_after.flesch_reading_ease,
            "created_at":       datetime.utcnow(),
        }
        if self._use_mongo:
            col = self._db["history"]
            res = await col.insert_one(doc)
            return str(res.inserted_id)
        else:
            doc["_id"] = str(len(self._fallback))
            self._fallback.append(doc)
            return doc["_id"]

    async def get_history(
        self, page: int = 1, limit: int = 20
    ) -> tuple[List[HistoryItem], int]:
        skip = (page - 1) * limit

        if self._use_mongo:
            col = self._db["history"]
            total = await col.count_documents({})
            cursor = col.find({}).sort("created_at", -1).skip(skip).limit(limit)
            docs = await cursor.to_list(length=limit)
        else:
            total = len(self._fallback)
            docs  = list(reversed(self._fallback))[skip : skip + limit]

        items = [
            HistoryItem(
                id=str(d.get("_id", d.get("request_id", ""))),
                original_text=d["original_text"][:200] + "…"
                if len(d["original_text"]) > 200 else d["original_text"],
                simplified_text=d["simplified_text"][:200] + "…"
                if len(d["simplified_text"]) > 200 else d["simplified_text"],
                level=d["level"],
                created_at=d.get("created_at", datetime.utcnow()),
                flesch_before=d.get("flesch_before", 0),
                flesch_after=d.get("flesch_after", 0),
            )
            for d in docs
        ]
        return items, total


db = Database()
