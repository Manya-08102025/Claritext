"""
ClariText — History Service
Persists simplification results + key terms to Supabase PostgreSQL,
and retrieves paginated history per user.
"""

import uuid
import logging
from typing import List, Tuple
from fastapi import HTTPException

from app.db.supabase_client import get_supabase
from app.models.schemas import SimplifyResponse, HistoryItem, KeyTerm

logger = logging.getLogger(__name__)


class HistoryService:

    async def save(self, user_id: str, result: SimplifyResponse) -> str:
        """
        Persist a completed simplification run.
          • Inserts a row into text_history.
          • Inserts key_terms rows linked to that history row.
        Returns the new history row id.
        """
        sb = get_supabase()

        history_id = str(uuid.uuid4())

        # ── Insert main record ───────────────────────────────────
        history_row = {
            "id":              history_id,
            "user_id":         user_id,
            "original_text":   result.original_text,
            "simplified_text": result.simplified_text,
            "difficulty_level":result.level.value,
            "flesch_before":   result.readability_before.flesch_reading_ease,
            "flesch_after":    result.readability_after.flesch_reading_ease,
            "fk_grade_before": result.readability_before.flesch_kincaid_grade,
            "fk_grade_after":  result.readability_after.flesch_kincaid_grade,
            "processing_ms":   result.processing_time_ms,
        }

        try:
            sb.table("text_history").insert(history_row).execute()
        except Exception as e:
            logger.warning(f"Failed to save history row: {e}")
            return history_id   # non-fatal — still return the id

        # ── Insert key terms ─────────────────────────────────────
        if result.key_terms:
            term_rows = [
                {
                    "id":         str(uuid.uuid4()),
                    "history_id": history_id,
                    "term":       kt.term,
                    "definition": kt.definition,
                    "domain":     kt.domain,
                }
                for kt in result.key_terms
            ]
            try:
                sb.table("key_terms").insert(term_rows).execute()
            except Exception as e:
                logger.warning(f"Failed to save key terms: {e}")

        logger.debug(f"Saved history {history_id} for user {user_id}")
        return history_id

    async def get_history(
        self,
        user_id: str,
        page: int = 1,
        limit: int = 20,
    ) -> Tuple[List[HistoryItem], int]:
        """
        Return paginated text_history rows for a given user.
        Ordered newest-first.
        """
        sb  = get_supabase()
        off = (page - 1) * limit

        # ── Total count ──────────────────────────────────────────
        count_res = (
            sb.table("text_history")
            .select("id", count="exact")
            .eq("user_id", user_id)
            .execute()
        )
        total = count_res.count or 0

        # ── Paginated rows ───────────────────────────────────────
        data_res = (
            sb.table("text_history")
            .select(
                "id, original_text, simplified_text, difficulty_level, "
                "flesch_before, flesch_after, processing_ms, created_at"
            )
            .eq("user_id", user_id)
            .order("created_at", desc=True)
            .range(off, off + limit - 1)
            .execute()
        )

        items = []
        for row in (data_res.data or []):
            orig = row["original_text"]
            simp = row["simplified_text"]
            items.append(HistoryItem(
                id=row["id"],
                original_text=orig[:200] + "…" if len(orig) > 200 else orig,
                simplified_text=simp[:200] + "…" if len(simp) > 200 else simp,
                level=row["difficulty_level"],
                flesch_before=row.get("flesch_before"),
                flesch_after=row.get("flesch_after"),
                processing_ms=row.get("processing_ms"),
                created_at=row["created_at"],
            ))

        return items, total

    async def get_detail(self, history_id: str, user_id: str) -> dict:
        """
        Return full detail for a single history entry including its key terms.
        Verifies ownership to prevent unauthorised access.
        """
        sb = get_supabase()

        # Fetch history row
        res = (
            sb.table("text_history")
            .select("*")
            .eq("id", history_id)
            .eq("user_id", user_id)   # ownership check
            .single()
            .execute()
        )

        if not res.data:
            raise HTTPException(status_code=404, detail="History entry not found.")

        row = res.data

        # Fetch associated key terms
        terms_res = (
            sb.table("key_terms")
            .select("term, definition, domain")
            .eq("history_id", history_id)
            .execute()
        )

        return {
            **row,
            "key_terms": [
                KeyTerm(term=t["term"], definition=t["definition"], domain=t.get("domain"))
                for t in (terms_res.data or [])
            ],
        }

    async def delete(self, history_id: str, user_id: str) -> None:
        """Delete a single history entry (and its key terms via CASCADE)."""
        sb = get_supabase()

        res = (
            sb.table("text_history")
            .delete()
            .eq("id", history_id)
            .eq("user_id", user_id)
            .execute()
        )

        if not res.data:
            raise HTTPException(status_code=404, detail="History entry not found.")


history_service = HistoryService()
