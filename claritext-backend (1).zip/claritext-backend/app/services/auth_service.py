"""
ClariText — Authentication Service
User registration, login, and token management backed by Supabase PostgreSQL.
"""

import uuid
import logging
from datetime import timedelta
from fastapi import HTTPException, status

from app.core.security import hash_password, verify_password, create_access_token, create_refresh_token, decode_token
from app.core.config import settings
from app.db.supabase_client import get_supabase
from app.models.schemas import RegisterRequest, LoginRequest, TokenResponse, UserOut

logger = logging.getLogger(__name__)


class AuthService:

    # ── Registration ─────────────────────────────────────────────

    async def register(self, req: RegisterRequest) -> UserOut:
        """
        Register a new user.
          1. Check email is not already taken.
          2. Hash the password.
          3. Insert into users table.
          4. Return the new user profile.
        """
        sb = get_supabase()

        # 1. Check for existing user
        existing = (
            sb.table("users")
            .select("id")
            .eq("email", req.email)
            .execute()
        )
        if existing.data:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An account with this email already exists.",
            )

        # 2. Hash password
        hashed = hash_password(req.password)

        # 3. Insert new user
        new_user = {
            "id":        str(uuid.uuid4()),
            "email":     req.email,
            "password":  hashed,
            "full_name": req.full_name,
        }
        result = sb.table("users").insert(new_user).execute()

        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create user account.",
            )

        row = result.data[0]
        logger.info(f"New user registered: {req.email}")
        return UserOut(
            id=row["id"],
            email=row["email"],
            full_name=row.get("full_name"),
            created_at=row["created_at"],
            is_active=row.get("is_active", True),
        )

    # ── Login ────────────────────────────────────────────────────

    async def login(self, req: LoginRequest) -> TokenResponse:
        """
        Authenticate a user and return JWT access + refresh tokens.
        """
        sb = get_supabase()

        # Fetch user by email
        result = (
            sb.table("users")
            .select("id, email, password, full_name, is_active")
            .eq("email", req.email)
            .single()
            .execute()
        )

        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password.",
            )

        row = result.data

        # Check account active
        if not row.get("is_active", True):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account is disabled. Contact support.",
            )

        # Verify password
        if not verify_password(req.password, row["password"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password.",
            )

        # Mint tokens
        token_data = {"sub": row["id"], "email": row["email"]}
        access_token  = create_access_token(token_data)
        refresh_token = create_refresh_token(token_data)

        logger.info(f"User logged in: {req.email}")
        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    # ── Token Refresh ────────────────────────────────────────────

    async def refresh(self, refresh_token: str) -> TokenResponse:
        """
        Issue a new access token from a valid refresh token.
        """
        payload = decode_token(refresh_token)

        if payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not a refresh token.",
            )

        token_data = {"sub": payload["sub"], "email": payload.get("email", "")}
        new_access  = create_access_token(token_data)
        new_refresh = create_refresh_token(token_data)

        return TokenResponse(
            access_token=new_access,
            refresh_token=new_refresh,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    # ── Get Profile ──────────────────────────────────────────────

    async def get_profile(self, user_id: str) -> UserOut:
        sb = get_supabase()
        result = (
            sb.table("users")
            .select("id, email, full_name, created_at, is_active")
            .eq("id", user_id)
            .single()
            .execute()
        )
        if not result.data:
            raise HTTPException(status_code=404, detail="User not found.")
        row = result.data
        return UserOut(
            id=row["id"],
            email=row["email"],
            full_name=row.get("full_name"),
            created_at=row["created_at"],
            is_active=row.get("is_active", True),
        )


auth_service = AuthService()
