"""
ClariText — NLP Service
Handles:
  • Readability scoring  (Flesch Reading Ease + Flesch-Kincaid Grade)
  • Key term extraction  (glossary lookup + heuristic long-word detection)

Production upgrade path:
  Replace extract_key_terms() with spaCy NER pipeline by uncommenting
  the spaCy block at the bottom and installing en_core_web_sm.
"""

import re
import logging
from typing import List
from app.models.schemas import ReadabilityScores, KeyTerm

logger = logging.getLogger(__name__)

# ── Vowel set for syllable counting ──────────────────────────────
_VOWELS = set("aeiouAEIOU")


# ══════════════════════════════════════════════════════════════════
#  READABILITY SCORING
# ══════════════════════════════════════════════════════════════════

def _count_syllables(word: str) -> int:
    """
    Approximate syllable count using vowel-cluster method.
    Handles silent-e rule and enforces minimum of 1.
    """
    word = word.lower().strip(".,!?;:'\"()")
    if len(word) <= 3:
        return 1
    count, prev_vowel = 0, False
    for ch in word:
        is_v = ch in _VOWELS
        if is_v and not prev_vowel:
            count += 1
        prev_vowel = is_v
    # Silent 'e' ending — doesn't form its own syllable
    if word.endswith("e"):
        count = max(1, count - 1)
    return max(1, count)


def compute_readability(text: str) -> ReadabilityScores:
    """
    Compute:
      Flesch Reading Ease  = 206.835 − 1.015×ASL − 84.6×ASW
      Flesch-Kincaid Grade = 0.39×ASL + 11.8×ASW − 15.59

    Where:
      ASL = average sentence length (words per sentence)
      ASW = average syllables per word
    """
    # Tokenize sentences
    raw_sents = re.split(r"[.!?]+", text)
    sentences = [s.strip() for s in raw_sents if s.strip()]
    n_sentences = max(1, len(sentences))

    # Tokenize words
    words = re.findall(r"\b[a-zA-Z]+\b", text)
    n_words = max(1, len(words))

    # Count syllables
    n_syllables = sum(_count_syllables(w) for w in words)

    asl = n_words / n_sentences                      # avg sentence length
    asw = n_syllables / n_words                      # avg syllables per word
    awl = sum(len(w) for w in words) / n_words       # avg word length

    flesch = 206.835 - 1.015 * asl - 84.6 * asw
    flesch = round(max(0.0, min(100.0, flesch)), 1)

    fk_grade = 0.39 * asl + 11.8 * asw - 15.59
    fk_grade = round(max(0.0, fk_grade), 1)

    # Human label
    if   flesch >= 90: label = "Very Easy"
    elif flesch >= 70: label = "Easy"
    elif flesch >= 60: label = "Standard"
    elif flesch >= 50: label = "Fairly Difficult"
    elif flesch >= 30: label = "Difficult"
    else:              label = "Very Difficult"

    return ReadabilityScores(
        flesch_reading_ease=flesch,
        flesch_kincaid_grade=fk_grade,
        avg_sentence_length=round(asl, 1),
        avg_word_length=round(awl, 2),
        label=label,
    )


# ══════════════════════════════════════════════════════════════════
#  KEY TERM GLOSSARY (academic domains)
# ══════════════════════════════════════════════════════════════════

TERM_GLOSSARY: dict[str, dict] = {
    # Biology
    "mitochondria":         {"definition": "Organelle that generates cellular energy (ATP) through aerobic respiration.", "domain": "Biology"},
    "atp":                  {"definition": "Adenosine triphosphate — the primary energy currency of cells.", "domain": "Biology"},
    "chemiosmosis":         {"definition": "ATP synthesis driven by a proton gradient across a membrane.", "domain": "Biology"},
    "phosphorylation":      {"definition": "Addition of a phosphate group to a molecule, often to activate it.", "domain": "Biology"},
    "electron transport":   {"definition": "Series of proteins that transfer electrons to build a proton gradient.", "domain": "Biology"},
    "dna":                  {"definition": "Deoxyribonucleic acid — the molecule carrying genetic instructions.", "domain": "Biology"},
    "rna":                  {"definition": "Ribonucleic acid — involved in protein synthesis and gene regulation.", "domain": "Biology"},
    "enzyme":               {"definition": "A protein that catalyses a specific biochemical reaction.", "domain": "Biology"},
    "osmosis":              {"definition": "Passive movement of water across a semi-permeable membrane.", "domain": "Biology"},
    "homeostasis":          {"definition": "A system's tendency to maintain stable internal conditions.", "domain": "Biology"},
    "allele":               {"definition": "One of two or more forms of a gene at a given locus.", "domain": "Genetics"},
    "phenotype":            {"definition": "Observable characteristics resulting from genetic expression.", "domain": "Genetics"},
    "genotype":             {"definition": "An organism's full set of genes, determining its traits.", "domain": "Genetics"},
    # Chemistry
    "catalyst":             {"definition": "A substance that increases reaction rate without being consumed.", "domain": "Chemistry"},
    "isotope":              {"definition": "Atoms of the same element with different neutron counts.", "domain": "Chemistry"},
    "entropy":              {"definition": "A measure of disorder or randomness in a thermodynamic system.", "domain": "Thermodynamics"},
    "oxidation":            {"definition": "Loss of electrons by a molecule, atom, or ion.", "domain": "Chemistry"},
    "reduction":            {"definition": "Gain of electrons by a molecule, atom, or ion.", "domain": "Chemistry"},
    "electrolysis":         {"definition": "Using electrical current to drive a non-spontaneous chemical reaction.", "domain": "Chemistry"},
    # Physics
    "quantum entanglement": {"definition": "Phenomenon where particles remain correlated regardless of separation distance.", "domain": "Physics"},
    "photon":               {"definition": "A discrete quantum of electromagnetic radiation (light).", "domain": "Physics"},
    "wave-particle duality":{"definition": "The concept that matter exhibits both wave and particle properties.", "domain": "Physics"},
    "refraction":           {"definition": "Bending of a wave as it passes from one medium to another.", "domain": "Physics"},
    # Computer Science
    "algorithm":            {"definition": "A step-by-step procedure for solving a computational problem.", "domain": "Computer Science"},
    "neural network":       {"definition": "A computing architecture modelled loosely on biological neurons.", "domain": "Machine Learning"},
    "gradient descent":     {"definition": "Optimisation algorithm that iteratively minimises a loss function.", "domain": "Machine Learning"},
    "transformer":          {"definition": "Deep learning architecture using self-attention for sequence modelling.", "domain": "NLP"},
    "tokenization":         {"definition": "Breaking text into smaller units (tokens) for NLP processing.", "domain": "NLP"},
    "backpropagation":      {"definition": "Algorithm that computes gradients of the loss with respect to model weights.", "domain": "Machine Learning"},
    "overfitting":          {"definition": "When a model memorises training data but fails to generalise.", "domain": "Machine Learning"},
    "api":                  {"definition": "Application Programming Interface — a set of rules for software communication.", "domain": "Software Engineering"},
    "recursion":            {"definition": "A function that calls itself to solve smaller sub-problems.", "domain": "Computer Science"},
    # Economics
    "elasticity":           {"definition": "Degree to which demand/supply responds to a price change.", "domain": "Economics"},
    "gdp":                  {"definition": "Gross Domestic Product — total monetary value of all goods/services produced.", "domain": "Economics"},
    "inflation":            {"definition": "General rise in the price level of goods and services over time.", "domain": "Economics"},
    "monetary policy":      {"definition": "Central bank actions to control money supply and interest rates.", "domain": "Economics"},
    # Mathematics
    "derivative":           {"definition": "Rate of change of a function with respect to a variable.", "domain": "Calculus"},
    "integral":             {"definition": "The area under a curve; the anti-derivative of a function.", "domain": "Calculus"},
    "eigenvalue":           {"definition": "A scalar by which a matrix stretches its corresponding eigenvector.", "domain": "Linear Algebra"},
    "hypothesis":           {"definition": "A proposed explanation for an observation, subject to testing.", "domain": "Research"},
}


# ══════════════════════════════════════════════════════════════════
#  KEY TERM EXTRACTION
# ══════════════════════════════════════════════════════════════════

_COMMON_WORDS = {
    "research", "however", "although", "therefore", "through", "different",
    "important", "following", "between", "another", "including", "students",
    "academic", "technical", "because", "example", "provides", "describe",
    "complete", "multiple", "together", "discussion", "information", "analysis",
    "structure", "knowledge", "understanding", "application",
}


def extract_key_terms(text: str, max_terms: int = 10) -> List[KeyTerm]:
    """
    Two-pass extraction:
      Pass 1 — Glossary lookup  (longest match first, case-insensitive)
      Pass 2 — Heuristic        (long words ≥9 chars not in common word list)
    """
    text_lower = text.lower()
    found: List[KeyTerm] = []
    seen:  set[str]      = set()

    # ── Pass 1: glossary ──────────────────────────────────────────
    for term in sorted(TERM_GLOSSARY, key=len, reverse=True):
        if term in text_lower and term not in seen:
            data = TERM_GLOSSARY[term]
            found.append(KeyTerm(
                term=term.title(),
                definition=data["definition"],
                domain=data.get("domain"),
            ))
            seen.add(term)
        if len(found) >= max_terms:
            break

    # ── Pass 2: heuristic for long unknown words ──────────────────
    if len(found) < max_terms:
        for word in set(re.findall(r"\b[a-zA-Z]{9,}\b", text)):
            wl = word.lower()
            if wl not in seen and wl not in _COMMON_WORDS:
                found.append(KeyTerm(
                    term=word,
                    definition="Technical term — refer to a domain-specific glossary for a precise definition.",
                    domain=None,
                ))
                seen.add(wl)
            if len(found) >= max_terms:
                break

    return found[:max_terms]


# ══════════════════════════════════════════════════════════════════
#  SERVICE SINGLETON
# ══════════════════════════════════════════════════════════════════

class NLPService:
    """Lightweight NLP service backed by rule-based processing."""

    def __init__(self):
        self._ready = False

    async def initialize(self):
        # Future: load spaCy model here
        # import spacy; self._nlp = spacy.load("en_core_web_sm")
        logger.info("NLP service initialised (rule-based pipeline).")
        self._ready = True

    def score_readability(self, text: str) -> ReadabilityScores:
        return compute_readability(text)

    def extract_terms(self, text: str, max_terms: int = 10) -> List[KeyTerm]:
        return extract_key_terms(text, max_terms)

    @property
    def ready(self) -> bool:
        return self._ready


nlp_service = NLPService()
