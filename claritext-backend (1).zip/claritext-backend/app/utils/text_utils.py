"""
ClariText — Text Utilities
Shared helpers used across services.
"""

import re
from typing import List


def word_count(text: str) -> int:
    """Count the number of words in a string."""
    return len(re.findall(r"\b[a-zA-Z]+\b", text))


def sentence_count(text: str) -> int:
    """Count the number of sentences in a string."""
    sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    return max(1, len(sentences))


def truncate(text: str, max_chars: int = 200, suffix: str = "…") -> str:
    """Truncate text to max_chars, appending suffix if truncated."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + suffix


def sentence_tokenize(text: str) -> List[str]:
    """Split text into individual sentences."""
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]


def word_tokenize(text: str) -> List[str]:
    """Split text into word tokens (alphabetic only)."""
    return re.findall(r"\b[a-zA-Z]+\b", text)
